package edu.cornell.gdiac.mistic;

/**
 * Created by Altair on 3/7/2017.
 */
public class BoardTuple {
    public boolean[][] a;
    public boolean[][] b;
    public BoardTuple(boolean[][] a, boolean[][] b) {
        this.a = a;
        this.b = b;
    }
}
