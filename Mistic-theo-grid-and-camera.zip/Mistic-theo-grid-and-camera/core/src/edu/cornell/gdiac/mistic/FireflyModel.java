package edu.cornell.gdiac.mistic;

/**
 * Created by beau on 3/18/17.
 */
public class FireflyModel {
}
